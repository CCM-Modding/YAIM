package mrtjp.projectred.compatability;

public class CompatabilityClientProxy extends CompatabilityProxy {


}
