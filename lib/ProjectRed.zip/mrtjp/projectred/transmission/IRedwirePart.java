package mrtjp.projectred.transmission;

public interface IRedwirePart extends IWirePart, IRedwireEmitter
{
}
