package mrtjp.projectred.transmission;

public interface IInsulatedRedwirePart extends IRedwirePart
{
    public int getInsulatedColour();
}
