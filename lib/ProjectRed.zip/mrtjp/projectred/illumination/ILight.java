package mrtjp.projectred.illumination;

public interface ILight {
    public boolean isOn();
}
