package mrtjp.projectred.core;

import mrtjp.projectred.ProjectRedCore;

public class CoreSPH {
	/**
	 * None yet... used for packet keys.
	 */
    public static Object channel = ProjectRedCore.instance;

}
